<?php
defined('BASEPATH') OR exit('No direct script access allowed');
use \Firebase\JWT\JWT;

class App extends CI_Controller {

	public function __construct() {
        parent::__construct();
        $this->output->cache(0);
        $this->output->delete_cache();
        $this->load->helper(array('url_helper','url','form'));
        $this->load->library(array('session','form_validation'));
        //$this->load->model('fn');
    }
  public function chat($type_chat,$subject_chat,$user,$chatto)
  {
    $res=array("success"=>false,"login"=>false,"msj"=>"Acceso restringido","data"=>null);
    if($this->user=$this->fn->validToken($this->input->get("auth")))
    {
      $res['login']=true;
      $chatfrom = $this->user;
      if(count($this->fn->getCampos(TABLE_PREFIX."chatsxusuario", ["iduser"=>$this->user,"idsubject"=>$subject_chat])) == 0)
      {
        $idayudas = null; $idback = null;
        $data = array(
          "iduser" => $this->user,
          "idsubject" => $subject_chat,
          "statuscode" => 1,
          "typechat" => 2,
          "extraid" => $idayudas,
          "idback" => $idback
        );
        $this->fn->pushtodb($data, TABLE_PREFIX."chatsxusuario");
      }
      $this->fn->updaterequest(TABLE_PREFIX."chats", array("idsubject"=>$subject_chat,"iduser"=>$chatto), array("statuscode"=>2));
      $res['data']=$this->getChat($chatfrom,$chatto,$type_chat,$subject_chat);
    }
    echo json_encode($res);
  }
  private function getChat($from,$to,$type_chat,$subject_chat)
  {
    $data=[];
    switch ($type_chat) {
      case "user":
        $buscar_mis_chats = $this->fn->getCampos(TABLE_PREFIX."chatsxusuario", array("iduser"=>$this->user,"typechat"=>1));
        $buscar_chat = null;
        if(count($buscar_mis_chats)>0)
        {
          foreach ($buscar_mis_chats as $key => $value) {
            $buscar_chat_back = $this->fn->getCampos(TABLE_PREFIX."chatsxusuario", array("iduser"=>$to,"idsubject"=>$value['idsubject']));
            if(count($buscar_chat_back)>0)
            {
              $buscar_chat = $buscar_chat_back[0]['idsubject'];
            }
          }
        }
        if($buscar_chat)
        {
          $subject_chat = $buscar_chat;
        }
        $data['chat']=$this->fn->getCamposAndJoin(TABLE_PREFIX."chats c", array("idsubject"=>$subject_chat), [USERS_TABLE.' u'],["u.idusers=c.iduser"], "CONCAT('','".URL_USUARIOS."', profileimage) as profileimage, c.chatmessage, chatdate, idchats,u.fullname,IF(iduser='".$this->user."', 'true', 'false') as owner,c.statuscode");
        foreach ($data['chat'] as $key => $value) {
          $data['chat'][$key]['chatdate']=date('H:i', strtotime($value['chatdate']));
          if($value['owner']=="true")
          {
            $data['chat'][$key]['owner']=true;
          }
          if($value['owner']=="false")
          {
            $data['chat'][$key]['owner']=false;
          }
          $data['chat'][$key]['readed']=$value['statuscode']=="2"?true:false;
        }
        $data['user']=$this->fn->getCampos(USERS_TABLE." u", array("idusers"=>$to), NULL, "IF(identi=1, CONCAT('', '".base_url()."uploads/images/usuarios/', profileimage), profileimage) as profileimage,fullname, idusers, 'true' as perfil")[0];
        break;
      default:
        $data['content']="";
        $data['chat']=[];
        break;
    }
    //$this->fn->updaterequest(TABLE_PREFIX."chats",  array("idsubject"=>$subject_chat,"iduser != "=>$this->user), array("statuscode"=>2));
    return $data;
  }
  public function mensaje($iduser,$uncode)
  {
    $res=array("success"=>false,"login"=>false,"msj"=>"Acceso restringido","data"=>null);
    if($this->user=$this->fn->validToken($this->input->post("auth")))
    {
      $info = $this->fn->getCampos(USERS_TABLE, array("idusers"=>$this->user));
      $type=$this->input->post("type");
      $id = explode("_", $uncode);
      if(count($id)>0)
      {
        $id=$id[1];
      }else{
        $id=null;
      }
      $find=$this->fn->getCampos(TABLE_PREFIX."chatsxusuario", array("idsubject"=>$uncode,"iduser"=>$this->user));
      if(count($find)==0)
      {
        $data=array(
          "iduser"=>$this->user,
          "idsubject"=>$uncode,
          "statuscode"=>0,
          "typechat"=>$type,
          "extraid"=>$id,
          "idback"=>$iduser
        );
        $data1=array(
          "iduser"=>$iduser,
          "idsubject"=>$uncode,
          "statuscode"=>0,
          "typechat"=>$type,
          "extraid"=>$id,
          "idback"=>$this->user
        );
        $q=$this->fn->pushtodb($data,TABLE_PREFIX."chatsxusuario");
        $q1=$this->fn->pushtodb($data1,TABLE_PREFIX."chatsxusuario");
      }
      $text=str_replace('"', "'", $this->input->post("text"));
      $random=$this->input->post("random");
      $hora=$this->input->post("hour");
      $fecha=date('Y-m-d ').$hora;
      $data=array(
        "iduser"=>$this->user,
        "idsubject"=>$uncode,
        "chatmessage"=>$text,
        "chatdate"=>$fecha,
        "statuscode"=>1
      );
      $q=$this->fn->pushtodb($data,TABLE_PREFIX."chats", true);
      if($q)
      {
        $send_push = true;
        $find_back=$this->fn->getCampos(TABLE_PREFIX."chatsxusuario", array("idsubject"=>$uncode,"iduser"=>$iduser,"statuscode"=>0));
        $res['otro']=$find_back;
        if(count($find_back)==0)
        {
          $send_push = false;
        }
        if($send_push)
        {
          $_WHO = $info[0]['fullname'];
          if($type==2)
          {
            $ayuda = $this->fn->getCampos(TABLE_PREFIX."ayudas", array("idayudas"=>$id));
            if(count($ayuda)&&$ayuda[0]['perfil']==1&&$ayuda[0]['idusuario']!=$iduser)
            {
              $_WHO = "Anónimo - (".$ayuda[0]['titulo'].")";
            }else{
              $_WHO .= " - (".$ayuda[0]['titulo'].")";
            }
          }
          if(function_exists('curl_init'))
          {
            $this->mensajeria->pushAplication($iduser, $_WHO.': '. $text, ["chat_conexion"=>["id"=>$info[0]['idusers'],"subject"=>$uncode]]);
          }
        }
      }
      $res['success']=true;
      $res['id']=$q;
      $res['random']=$random;
    }
    echo json_encode($res);
  }
}