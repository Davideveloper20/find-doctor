<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
      
    <footer class="sticky-footer bg-white fixed-bottom" style="z-index: -1">
      	<div class="container my-auto">
	        <div class="copyright text-center my-auto">
	          Copyright &copy; <?php echo date('Y'); ?> <div class="bullet"></div> Design By <a href="https://solucionesstar.com/">Soluciones Star SAS</a>
	        </div>
   	 	</div>
  	</footer>

<?php $this->load->view('_partials/js'); ?>