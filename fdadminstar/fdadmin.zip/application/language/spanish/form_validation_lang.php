<?php
$lang["msg_first_name"] = "First Name";