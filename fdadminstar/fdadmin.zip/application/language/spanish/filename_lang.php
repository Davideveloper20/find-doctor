<?php
$lang["upload_invalid_filetype"] = "Tipo de archivo inválido";