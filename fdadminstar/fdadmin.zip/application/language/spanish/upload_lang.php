<?php
$lang["upload_invalid_filetype"] = "Tipo de archivo inválido";
$lang["upload_no_file_selected"] = "No se seleccionaron archivos";
$lang["upload_invalid_dimensions"] = "Dimensiones de imagen no válidas";