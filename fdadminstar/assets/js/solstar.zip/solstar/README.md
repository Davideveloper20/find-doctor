## SolStar Solution v1.0 - 24/07/2019 - ECMAScript 6 

# Actualizar archivos agregados al .gitignore
Esto borrara el cache de git en local para todos los archivos
```
git rm -r --cached .
```
Para un archivo o carpeta especifica ejecutar respectivamente según el caso:
```
git rm  --cached path/to/file.ext
```
o
```
git rm -r --cached path/to/removefromcahce
```

Luego se debe actualizar de nuevo el branch o repositorio
```
git add .
git commit -m "Actualizando .gitignore"
git push
```

#Archivos de configuracion ignorados
El archivo de configuración es ignorado, por ejemplo
*conf.js*

El cual se encuantra renombrado de la siguiente manera:
*conf.example.js*

A manera de ejemplo de la estructura de dichos archivos,
para que en el momento de hacer push en otra ubicación
no se sobre escriban las configuraciones propias de cada
locación o servidor y solo se agreguen manualmente las necesarias
y evitar conflictos en los archivos.

Al momento de clonar simplemente se copia y pega estos archivos 
y se renombran.

# Utiliza como submodulo
Para utilizar como submodulo este repositorio
luego de clonar/crear un proyecto debe iniciarse de la siguiente manera:

Usando https:
```
git submodule add https://gitlab.com/sstarteam/sses6.git path/to/js/solstar
```

Usando ssh:
```
git submodule add git@gitlab.com:sstarteam/sses6.git path/to/js/solstar
```


Al clonar un repositorio que ya tiene el submodulo se creará la carpeta del mismo pero vacia
para actualizar o descargar el submodulo basta con los siguientes comandos:
```
# Proyecto a clonar
git clone git://github.com/schacon/myproject.git

# para inicializar el archivo de configuración local
git submodule init

# para recuperar (fetch) todos los datos del proyecto y extraer (checkout) la confirmación de cambios adecuada desde el proyecto padre
git submodule update
```

Sí posterior el submodulo es actualizado es su repositorio, lo cual debe ser y luego actualizar en los 
proyectos padres para evitar conflictos de código, debe ejecutarse lo siguiente para que se actualice
el submodulo:

```
git submodule update
```

# *Configuraciones GIT recomendadas*
```
# Para evitar validacion en cambios de permisos de acceso a los archivos
git config --add --global core.filemode false
git config --add --global core.fileMode false

# Para el cambio automatico del caracter EOL en los archivos segun el OS
git config --global core.autocrlf input

# Para subir/bajar cambios en la rama actual
git config --global push.default simple

# verificará todos los objetos recibidos. Abortará en el caso de un objeto malformado o un enlace roto
git config --system receive.fsckObjects true

# Tamaño máximo en bytes del búfer utilizado por los transportes HTTP inteligentes al enviar datos al sistema remoto
git config --global http.postBuffer 5242880

#se habilitará el resumen de submódulos y se mostrará un resumen de confirmaciones para submódulos modificados
git config --global status.submoduleSummary true

#Otras para optimizar el comportamiento de git
git config --global branch.autosetupmerge always
git config --global push.default current
git config --global gc.auto 0
git config --global color.ui auto
git config --global color.diff auto
git config --global color.status auto
git config --global color.branch auto
git config --global push.default simple
```

# Para minifcar y sourcemaps
```
npm install
gulp solstar
```